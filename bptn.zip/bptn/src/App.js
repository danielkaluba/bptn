import React from "react";
import {Routes, Route, Switch, BrowserRouter} from 'react-router-dom';
import GlobalSate from "./context/GlobalState"
import './App.css';
import Movies from "./components/Movies"
import LikedMovies from "./components/LikedMovies"
import Navigation from "./components/Navigation"

function App() {
    return (
        <GlobalSate>

            <BrowserRouter>
                <Navigation/>
                <Routes>
                    <Route path="/" element={<Movies/>}/>
                    <Route path="/liked" element={<LikedMovies/>}/>
                </Routes>
            </BrowserRouter>
        </GlobalSate>
    );
}

export default App;
