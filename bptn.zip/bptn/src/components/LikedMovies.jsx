import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import MovieContext from "../context/movies-context"

const LikedMovies = () => {
    const context = useContext(MovieContext);
    return (
        <>
            <section className="container">
                <div className="columns">
                    <div className="column">
                        {
                            context.liked.length <= 0 && <p>No movies have been liked!</p>
                        }
                        <>
                            {context.liked.map(movie => (
                                <article key={movie.id} className="post">
                                    <h4>{movie.original_title}</h4>
                                    <p>{movie.overview}</p>
                                    <div className="media">
                                        <div className="media-left">
                                            <p className="image is-64x64">
                                                <img loading="lazy" src={'//www.themoviedb.org/t/p/w300_and_h450_bestv2' + movie.poster_path} className='media-img' title={movie.original_title} alt={movie.original_title} />
                                            </p>
                                        </div>
                                        <div className="media-content">
                                            <div className="content">
                                                <p>
                                                    <span className="link">{movie.original_language}</span> {movie.release_date} &nbsp;
                                                    <span className="tag">
                                                        Popularity: {movie.popularity}
                                                    </span>
                                                </p>
                                                <span onClick={context.removeMovieFromLiked.bind(this, movie)}>
                                                    <span className="link">Unlike <i className="fa fa-thumbs-dwon"></i></span>
                                                </span>
                                            </div>
                                        </div>
                                        <div className="media-right">
                                            <span className="has-text-grey-light">
                                                <i className="fa fa-comments"></i> {movie.vote_average}
                                            </span>
                                        </div>
                                    </div>
                                </article>
                            ))}
                        </>
                    </div>
                </div>
            </section>
        </>
    )
}

export default LikedMovies