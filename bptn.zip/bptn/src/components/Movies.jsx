import React, {useState, useEffect} from 'react';
import MoviesService from "../services/movies.service"
import MovieContext from "../context/movies-context"

const Movies = () => {
    // eslint-disable-next-line
    const [movies, setMovies] = useState([]);

    useEffect(() => {
        MoviesService.fetchMovies().then((payload) => {
            setMovies(payload.results)
        })
    }, []);

    return (
        <>
            <section className="container">
                <div className="columns">
                    <div className="column">
                        <MovieContext.Consumer>
                            {
                                (context, ) => (
                                    <div className="box content">
                                        {
                                            context.movies.map(movie => (
                                                <article key={movie.id} className="post">
                                                    <h4>{movie.original_title}</h4>
                                                    <p>{movie.overview}</p>
                                                    <div className="media">
                                                        <div className="media-left">
                                                            <p className="image is-64x64">
                                                                <img loading="lazy" src={'//www.themoviedb.org/t/p/w300_and_h450_bestv2' + movie.poster_path} className='media-img' title={movie.original_title} alt={movie.original_title} />
                                                            </p>
                                                        </div>
                                                        <div className="media-content">
                                                            <div className="content">
                                                                <p>
                                                                    <span className="text-primary">{movie.original_language}</span> {movie.release_date} &nbsp;
                                                                    <span className="tag">
                                                                        Popularity: {movie.popularity}
                                                                    </span>
                                                                </p>
                                                                <span onClick={context.addMovieToLiked.bind(this, movie)}>
                                                                    <span className="link">
                                                                        Like <i className="fa fa-thumbs-up"></i>
                                                                    </span>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div className="media-right">
                                                            <span className="has-text-grey-light">
                                                                <i className="fa fa-comments"></i> {movie.vote_average}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </article>
                                            ))
                                        }
                                    </div>
                                )
                            }
                        </MovieContext.Consumer>
                    </div>
                </div>
            </section>

        </>


    )

}

export default Movies;