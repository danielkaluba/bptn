import React from 'react';
import { NavLink } from "react-router-dom";

const Navigation = () => {
    const logoPath = 'https://www.themoviedb.org/assets/2/v4/logos/v2/blue_short-8e7b30f73a4020692ccca9c88bafe5dcb6f8a62a4c6bc55cd9ba82bb2cd95f6c.svg'
    return (
        <nav className="navbar is-white topNav">
            <div className="container">
                <div className="navbar-brand">
                    <a href="/" className="navbar-item">
                        <img src={logoPath} title="Brand Name" alt="Brand Name" width="112" height="28"/>
                    </a>
                    <div className="navbar-burger burger" data-target="topNav">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div id="topNav" className="navbar-menu">
                    <div className="navbar-start">
                        <NavLink to="/" className="navbar-item">
                            Home
                        </NavLink>
                        <NavLink to="/liked" className={'navbar-item'}>
                            Liked Movies
                        </NavLink>
                    </div>
                </div>
            </div>
        </nav>
    )
}

export default Navigation;