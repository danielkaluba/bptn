import React, { useState, useReducer } from "react";
import MoviesService from "../services/movies.service"

import MovieContext from "./movies-context"
import {movieReducer, LIKE_MOVIE, UNLIKE_MOVIE } from "./reducers"

const GlobalState = props => {
    const [movies, setMovies] = useState([])

    MoviesService.fetchMovies().then((payload) => {
        setMovies(payload.results)
    })

    const [likedMoviesState, dispatch] = useReducer(movieReducer, { liked: [] });

    const addMovieToLiked = movie => {
        setTimeout(() => {
            dispatch({ type: LIKE_MOVIE, movie: movie });
        }, 700);
    };

    const removeMovieFromLiked = movie => {
        setTimeout(() => {
            dispatch({ type: UNLIKE_MOVIE, movie: movie })
        })
    }

    return (
        <MovieContext.Provider
            value={{
                movies:movies,
                liked: likedMoviesState.liked,
                addMovieToLiked: addMovieToLiked,
                removeMovieFromLiked: removeMovieFromLiked
            }}
        >
            {props.children}
        </MovieContext.Provider>
    )
}

export default GlobalState;
