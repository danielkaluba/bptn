import React from "react";
import MoviesService from "../services/movies.service"


const getMovies = () => {
    MoviesService.fetchMovies().then((payload) => {
        return payload.results
    })
}

export default React.createContext({
    movies: getMovies,
    likedMovies: [],
    addMovieToLiked: movies => {},
    removeMovieFromLiked: movies => {}
})