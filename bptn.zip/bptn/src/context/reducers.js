export const LIKE_MOVIE = "LIKE_MOVIE";
export const UNLIKE_MOVIE = "UNLIKE_MOVIE";

const likeMovie = (movie, state) => {
    const likedMovieList = [...state.liked]
    const movieItemIndex = likedMovieList.findIndex(
        item => item.id === movie.id
    )

    if (movieItemIndex < 0) {
        likedMovieList.push({ ...movie });
    } else {
        const updatedItem = {
            ...likedMovieList[movieItemIndex]
        };
        likedMovieList[movieItemIndex] = updatedItem;
    }
    return { ...state, liked: likedMovieList };
}

const dislikeMovie = (movie, state) => {
    const likedMovieList = [...state.liked]
    const movieItemIndex = likedMovieList.findIndex(
        item => item.id === movie.id
    )

    return { ...state, liked: [
        ...state.liked.slice(0, movieItemIndex),
        ...state.liked.slice(movieItemIndex + 1)
    ] }
}

export const movieReducer = (state, action) => {
    switch (action.type) {
        case LIKE_MOVIE:
            return likeMovie(action.movie, state);
        case UNLIKE_MOVIE:
            return dislikeMovie(action.movie, state);
        default:
            return state;
    }
};
