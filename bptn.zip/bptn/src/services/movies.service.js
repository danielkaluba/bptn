import axios from "axios";

const API_KEY = "d0f5f2e135336200362af8a1a73acb17";

const fetchMovies = async () => {
    return await axios.get(` https://api.themoviedb.org/3/movie/popular?api_key=${API_KEY}`).then((response) => {
        const payload = response?.data || response
        return payload;
    }).catch((error) => {
        const res = error.response?.data || error
        const e = JSON.stringify(res, null, 2);
        console.log(`Fetching movies failed; ${e}`)
    })
}

const MoviesService = {
    fetchMovies
}

export default MoviesService;